library(dplyr)
library(car)
library(leaflet)
library(shinycssloaders)
library(scales)
library(lattice)
library(dplyr)
library(shiny)
library(RColorBrewer)
library(plotly)
library(readr)
library(quanteda)
library(corpus)
library(tm)
library(qdap)
library(dplyr)
library(wordcloud)
library(plotrix)
library(dendextend)
library(ggplot2)
library(ggthemes)
library(RWeka)

bikemaps <- read.csv("data/Bikemaps(collision).csv")
clusters <- read.csv("MyData.csv")
Minorinjuries <- read.csv("minor.csv")
Severeinjuries <- read.csv("severe.csv")

bikemaps$cluster = clusters$ID


#Removing the commas after the bikemaps collions section
bikemaps$incident_with<-gsub(",.*", "", bikemaps$incident_with)
bikemaps$incident_with<-recode(bikemaps$incident_with,"c('Animal', 'Train Tracks', 'Other', 'Sign/Post', 'Pothole','Lane divider')='Other'")
bikemaps$date =  lapply(bikemaps$date, function(x) format(as.Date(x, format ='%Y-%m-%d'), '%Y-%m-%d'))
bikemaps$collision <- 1:186

cleantable <- bikemaps %>%
  select(
    Type = i_type,
    With = incident_with,
    Date = date,
    Details = details,
    Riding = riding_on,
    Terrain = terrain,
    Direction = direction,    
    Turning = turning,
    Age = age,
    Sex = sex,
    Longitude = longitude,
    Latitude = latitude,
    X = X,
    Y = Y
  )



