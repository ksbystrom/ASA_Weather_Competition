library(leaflet)
library(shinycssloaders)
library(shiny)

navbarPage("Food League", id="nav",
           tabPanel("Interactive Map",
                    div(class="outer",
                        tags$head(
                          # Include our custom CSS
                          includeCSS("styles.css"),
                          includeScript("gomap.js")
                        ),
                        #Show map
                        leafletOutput("map", width="100%", height="100%"),
                        
                        #Create Input Panel that fades in/ out
                        absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                      draggable = TRUE, top = 60, left = "auto", right = 20, bottom = "auto",
                                      width = 450, height = "auto",
                                      h2("Bike Collision Explorer"),
                                      selectInput("color", "Color Variable", c("Collision Cluster" ="cluster", "Incident With" = "incident_with"), selected = "incident_with"),
                                      
                                      withSpinner(plotlyOutput("hist1", width = "100%", height = 200)),
                                      withSpinner(plotlyOutput("hist2", width = "100%", height = 200))
                        )
                    )
           ),
           tabPanel("Data Explorer",
                               tags$head(
                                 # Include our custom CSS
                                 includeCSS("styles.css"),
                                 includeScript("gomap.js")
                               ),
                               fluidRow(
                                 column(3,
                                        selectInput("terrain", "Terrain", c("All terrains"="", "Uphill" = "Uphill", "Flat" = "Flat", "Downhill" = "Downhill"), multiple=TRUE)
                                 ),
                                 column(3,
                                        selectInput("sex", "Sex",  c("All sexes"="", "Other" = "Other", "Male" = "M", "Female" = "F"), multiple=TRUE)
                                 ),
                                 column(3,
                                        selectInput("direction", "Direction",  c("All directions"="", "North" ="N", "South" = "S", "East" = "E", "West" = "W"), multiple=TRUE)
                                 )
                               ),
                               fluidRow(
                                 column(3,
                                        numericInput("maxYear", "Youngest Birth Year", min=1900, max=2020, value=2018)
                                 ),
                                 column(3,
                                        numericInput("minYear", "Oldest Birth Year", min=1900, max=2020, value=1918)
                                 )
                               ),
                               hr(),
                               DT::dataTableOutput("biketable")
                      ),
           tabPanel("Collision Profiles",
                    tags$head(
                      # Include our custom CSS
                      includeCSS("styles.css")
                    ),
                    fluidRow(
                      column(3, align = "left",
                             img(src='Cluster1.png', align = "left", height = '250px', width = '250px')),
                      column(9, align = "left",
                             h2("Cluster 1: The Classic Collisions"),
                             h5('Cluster Description: We did some summary statistics on the collisions data based on the cluster ID’s and we see that the frequency of males (69) is greater than the frequency of females (36) with an average age of 42 years and the most common object involved besides the cyclists are vehicles. The audience of this cluster seem to be those who get into a “Classic Collision’. Certain keywords such as “suddenly”, “without”,”looking”, “realized” etc as well as general words like “bike”, “car”, “right”, “intersection”, “stopped”. '),
                             h5('Targeted Solutions:The problems associated with this cluster are common problems thus require basic solutions. One of the troubled areas was near the hospital, here is a quote from the details : “Pedestrians cross every which way at the hospital! “. One way to solve this problem is to enforce pedestrians to use crosswalks. A lot of the problems from the cluster pertains to vehicle drivers not following the traffic laws, so an increased police presence could remedy this. Smart signs for vehicles to notice the cyclists on/near the road would help. '))
                    ),
                    fluidRow(
                      column(3, align = "left",
                             img(src='Cluster2.png', align = "left", height = '250px', width = '250px')),
                      column(9, align = "left",
                             h2("Cluster 2: The Turning Collisions"),
                             h5('Cluster Description: We did some summary statistics on the collisions data based on the cluster ID’s and we see that the frequency of females (17) is greater than the frequency of males (9) with an average age of 43 years and the most common object involved besides the cyclists are vehicle. The most common objects involved were vehicles and animals. The audience of this cluster seem to be those who get into avoidable accidents. Certain keywords such as  “right”, “left”, “turn”,“suddenly”, “without”,”looking”, “realized” ,”visibility”,etc. This highlights to possibility of people avoiding an object leading to them colliding into another object. '),
                              h5("Targeted Solutions: Streets that pose a problem are Seaside -Science world,  and West 10th. In this cluster, we see that most  accidents could have been avoided if cyclists had training in handling quick turning/ stopping situations. We propose Biking Licensing that is relatively inexpensive but require a test to compress the amount of collisions that occur between cyclists and vehicles. Alternatively, restricting bike access for narrow, high-accident streets with street-parking on both sides such as West 10th.  This is only advised if there are convenient alternate routes for cyclists. "))
                    ),
                    fluidRow(
                      column(3, align = "left",
                             img(src='Cluster4.png', align = "left", height = '250px', width = '250px')),
                      column(9, align = "left",
                             h2("Cluster 4: The Oddballs"),
                             h5('Cluster Description:We did some summary statistics on the collisions data based on the cluster ID’s and we see that the frequency of males (3) is greater than the frequency of females (0) with an average age of 40 years and the most common object involved besides the cyclist are vehicles, curb and pedestrian. Based on the most appeared words “ tight”, “path”, “curb”, “ran”, etc. The details of the collisions seem to be unusual. '),
                             h5('Targeted Solutions: Cluster 4 has a very small sample size, so there is no real solution,  however here are the details submitted by users: “head-on collision with a car driving southbound (wrong way on a one-way street)”, “Car Ran red light and made right turn around the corner with rear wheels tight to the curb.” and “Car passenger jumped out of car, ran …., without looking in either direction. 1st cyclist veered in front to avoid her, the rest of the cyclists went behind her. Spooked by 1st bike, she ran backwards into me, caught my handlebars. I went flying into pavement." '))
                    ),
                    fluidRow(
                      column(12, align = "left",
                             h3("***Clusters 3 and 5 are too small to perform analysis."))
                    )),
           tabPanel("About the Developers",
                    tags$head(
                      # Include our custom CSS
                      includeCSS("styles.css"),
                      includeScript("gomap.js")
                    ),
                    
                    fluidRow( # Picture Row
                      column(4, align = "center",
                             img(src='Kristen.jpg', align = "center", height = '200px', width = '200px')),
                      column(4, align = "center",
                             img(src='ZhiYuh.jpg', align = "center", height = '200px', width = '200px')),
                      column(4, align = "center",
                             img(src='Alice.png', align = "center", height = '200px', width = '200px'))
                    ),
                    fluidRow( # Name Row
                      column(4, align = "center",
                             h3("Kristen Bystrom")),
                      column(4, align = "center",
                             h3("Zhi Yuh Ou Yang")),
                      column(4, align = "center",
                             h3("Alice Roberts"))
                    ),
                    fluidRow( # Job Title
                      column(4, align = "center",
                             h6("Data Scientist/ Web Developer")),
                      column(4, align = "center",
                             h6("Data Scientist/ Data Engineer")),
                      column(4, align = "center",
                             h6("Data Scientist/ Chief Strategist"))
                    ),
                    fluidRow( # green bar
                      column(4, align = "center",
                             img(src='greenbar.png', align = "center", height = "15px", width = "100%")),
                      column(4, align = "center",
                             img(src='greenbar.png', align = "center", height = "15px", width = "100%")),
                      column(4, align = "center",
                             img(src='greenbar.png', align = "center", height = "15px", width = "100%"))
                    ),
                    fluidRow( # Bio
                      column(4, align = "center",
                             h4("Kristen is a 5th year statistics and computing science student at Simon Fraser University. Her research collides the world of social media marketing with data science and statistics. She is the president of the SFU Statistics and Actuarial Science Student Association and in her free time enjoys seeing live theatre and playing board games.")),
                      column(4, align = "center",
                             h4("Zhi Yuh is a 4th year statistics and economics student from Simon Fraser University. He has been involved in weather, health, and language statistics reasearch projects. You may have seen him present at the Joint Statistical Meeting this year. He loves badminton and the rainy Vancouver weather.")),
                      column(4, align = "center",
                             h4("Alice Roberts is a 4th year applied mathematics student with a minor in economics from Simon Fraser University. She is passionate about finding cutting edge mathematical tools that she can use for applications in data science and finance. Her hobbies include volleyball, dance, shopping and hiking."))
                    ),
                    fluidRow( # green bar
                      column(4, align = "center",
                             img(src='greenbar.png', align = "center", height = "15px", width = "100%")),
                      column(4, align = "center",
                             img(src='greenbar.png', align = "center", height = "15px", width = "100%")),
                      column(4, align = "center",
                             img(src='greenbar.png', align = "center", height = "15px", width = "100%"))
                    ),
                    fluidRow( # email
                      column(4, align = "center",
                             h6("ksbystrom@gmail.com")),
                      column(4, align = "center",
                             h6("ouyangzyuh@gmail.com")),
                      column(4, align = "center",
                             h6("roberts.alice04@gmail.com"))
                    ),
                    fluidRow( # linkedin
                      column(4, align = "center",
                             tags$a(href="https://www.linkedin.com/in/kristen-bystrom-45583aa9/", "Kristen's LinkedIn!")),
                      column(4, align = "center",
                             tags$a(href="https://www.linkedin.com/in/zhi-yuh-ou-yang-31a8b6aa/", "Zhi Yuh's LinkedIn")),
                      column(4, align = "center",
                             tags$a(href="https://www.linkedin.com/in/alice-roberts-41146916a/", "Alice's LinkedIn"))
                    )
           ),
           conditionalPanel("false", icon("crosshair"))
)