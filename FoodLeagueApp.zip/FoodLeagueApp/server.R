function(input, output, session) {
  
  # Create the map
  output$map <- renderLeaflet({
    leaflet() %>%
      addTiles(
        urlTemplate = "//{s}.tiles.mapbox.com/v3/jcheng.map-5ebohr46/{z}/{x}/{y}.png",
        attribution = 'Maps by <a href="http://www.mapbox.com/">Mapbox</a>'
      ) %>%
      setView(lng = -123.0, lat = 49.24, zoom = 11)
  })
  
  #Create first vis in Menu
  output$hist1 <- renderPlotly({
    p <- ggplot(data=bikemaps, aes(x=incident_with)) +
      geom_bar(stat="count", fill = '#00DD00')+
      ggtitle("Cyclist Collided With")+
      ylab("Count")+
      theme_minimal()+
      theme(axis.title.x=element_blank(),
            axis.text.x=element_blank(),
            axis.ticks.x=element_blank())
    ggplotly(p, hoverinfo = "count")

    })
  output$hist2 <- renderPlotly({ 
    plot_ly(data = Minorinjuries, x = ~Date) %>%
      add_lines(data = Minorinjuries, y = ~Frequency, line = list(color = "blue", width = 1), name = "Minor Injuries") %>%
      add_lines(data = Severeinjuries, y = ~Frequency, line = list(color = '#00DD00', width = 1), name = "Severe Injuries")%>%
      layout(title = 'Time Series of Severe and Minor Injuries', showlegend = FALSE)
    })
  
  output$biketable <- DT::renderDataTable({
    df <- filter(cleantable,
          Age >= input$minYear,
          Age <= input$maxYear,
          is.null(input$terrain) | Terrain %in% input$terrain,
          is.null(input$sex) | Sex %in% input$sex,
          is.null(input$direction) | Direction %in% input$direction
       ) 
    #   mutate(Action = paste('<a class="go-map" href="" data-lat="', Latitude, '" data-long="', Longitude, '"><i class="fa fa-crosshairs"></i></a>', sep=""))
    #action <- DT::dataTableAjax(session, df)
    
    DT::datatable(df, escape = FALSE)
  })
  
  # This observer is responsible for maintaining the circles and legend,
  # according to the variables the user has chosen to map to color and size.
 observe({
  colorBy <- input$color
  colorData <- bikemaps[[colorBy]]
  pal <- colorFactor(c("blue", '#00DD00', "orange", "red", "purple", "yellow"), colorData)
  leafletProxy("map", data = bikemaps) %>% 
    clearShapes() %>%
    addCircleMarkers(~longitude, ~latitude, radius=8, layerId=~collision,
                stroke=FALSE, fillOpacity=0.6, fillColor=pal(colorData))%>%
    addLegend("bottomleft", pal=pal, values = colorData, title=colorBy, layerId="colorLegend")
  })

 # Custom function to show a popup at the given location
 showColPopup <- function(collision, lat, lng) {
   selectedCol <- bikemaps[bikemaps$collision == collision,]
   content <- as.character(tagList(
     tags$h4("Date:", selectedCol$date),
     tags$br(),
     tags$h6("Details: ", selectedCol$details)
   ))
   leafletProxy("map") %>% addPopups(lng, lat, content, layerId = collision)
 }
 
#When map is clicked, show a popup with city info
 observe({
   leafletProxy("map") %>% clearPopups()
   event <- input$map_marker_click
   print(event)
   if (is.null(event))
      return()
   
   isolate({
     showColPopup(event$id, event$lat, event$lng)
   })
 })
 
}